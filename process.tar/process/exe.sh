#!/bin/sh

python process.py > out.txt 
