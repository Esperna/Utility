writePath = './cert.txt'
readPath1 = './hoge.key'
readPath2 = './fuga.key'
readPath3 = './foo.key'

def main():
    with open(writePath) as f0:
        for line in f0.readlines():
            print(line)
            if line == "<key>\n":
                dispFile(readPath1)
            elif line == "<crt>\n":
                dispFile(readPath2)
            elif line == "<abc>\n":
                dispFile(readPath3)

def dispFile(path):
    with open(path) as f:
        s = f.read()
        print(s)

if __name__ == "__main__":
    main()

